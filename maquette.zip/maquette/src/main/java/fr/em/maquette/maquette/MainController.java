package fr.em.maquette.maquette;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.MenuItem;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import java.io.File;
import java.util.Optional;

public class MainController {
    @FXML
    MenuItem enregistrer;
    @FXML
    MenuItem enregistrerSous;
    @FXML
    MenuItem fermer;
    @FXML
    MenuItem nouveau;
    @FXML
    MenuItem quitter;

    private Main mainApp;

    @FXML
    private void initialize (){
        menuItemsDisable(true);
    }
    @FXML
    private void menuItemsDisable(boolean b) {
        enregistrer.setDisable(b);
        enregistrerSous.setDisable(b);
        fermer.setDisable(b);
        nouveau.setDisable(b);
    }
    @FXML
    public void fichierOuvrir(){
        mainApp.repertoireChanged();
        //Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        //alert.getButtonTypes().clear();
        //alert.getButtonTypes().add(ButtonType.YES);
        //alert.getButtonTypes().add(ButtonType.CANCEL); // ???
        //Optional<ButtonType> result = alert.showAndWait();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Titre1");
        fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Text files","*.txt"));
        fileChooser.setInitialDirectory(new File("C:\\Java\\dataSet"));
        File selectedFile = fileChooser.showOpenDialog(mainApp.getPrimaryStage());
        if (selectedFile != null){
            mainApp.getPrimaryStage().setTitle(Main.APP_NAME + " - " + selectedFile.getName());
            mainApp.setRepertoire(selectedFile);
            mainApp.getRepertoire().charger();
            mainApp.showGestionContact();
            menuItemsDisable(false);
        }
    }
    @FXML
    private void fichierFermer() {
        menuItemsDisable(true);
        mainApp.fermer();
    }
    @FXML
    private void fichierNouveau(){
        fichierFermer();
        fichierOuvrir();
    }
    @FXML
    private void fichierQuitter(){
        Platform.exit();
    }

    @FXML
    private void Enregistrer(){
        mainApp.getRepertoire().enregistrer();
    }

    public void setMainApp(Main main) {
        this.mainApp = main;
    }
}