package fr.fs.observer;
public interface Observer
{
  void actualise(Observable observable);
}
