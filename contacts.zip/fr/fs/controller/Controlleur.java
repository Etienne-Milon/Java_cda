package fr.fs.controller;

import fr.fs.vue.Menu;
import fr.fs.vue.VueRepertoire;

import java.util.ArrayList;
import java.util.Arrays;

public class Controlleur {

    public static void main(String[] args) {
        VueRepertoire vueRepertoire = new VueRepertoire();
        ArrayList<String> optionsLimitees = new ArrayList(Arrays.asList("Mettre fin au programme",
                "Charger un fichier de contacts"));

        ArrayList<String> optionsCompletes = new ArrayList(Arrays.asList("Mettre fin au programme",
                "Charger un fichier de contacts", "Lister les contacts", "Ajouter un contact", "Modifier un contact",
                "Supprimer un contact", "Enregistrer le fichier"));
        Menu menu = new Menu("Gestion de contacts", optionsLimitees);
        int rep;
        do {
            rep = menu.choisirUneOption();
            switch (rep) {
                case 1 -> {
                    vueRepertoire.charger();
                    menu = new Menu("Gestion de contacts", optionsCompletes);
                }
                case 2 -> vueRepertoire.lister();
                case 3 -> vueRepertoire.ajouter();
                case 4 -> vueRepertoire.modifier();
                case 5 -> vueRepertoire.supprimer();
                default -> vueRepertoire.enregistrer();
            }
        } while (rep != 0);
        System.out.println("\nAu revoir !!!");
    }
}
