package fr.fs.vue;

import fr.fs.metier.Personne;
import fr.fs.metier.Repertoire;
import fr.fs.outils.Saisie;

import java.util.ArrayList;

public class VueRepertoire {
    private Repertoire repertoire;

    public boolean charger() {
        if (repertoire != null) {
            enregistrer();
        }
        repertoire = new Repertoire(
                Saisie.saisirUneChaine("Nom du fichier : "));
        return true;
    }

    public void enregistrer() {
        if (repertoire == null || !repertoire.isModified())
            return;
        if (Saisie
                .saisirUneChaineMaj(
                        "Voulez-vous enregistrer les modifications ?", "ON", 1)
                .equals("O")) {
            repertoire.enregistrer();
        }
    }

    public void ajouter() {
        String nom = Saisie.saisirUneChaine("Saisir le nom : ");
        String prenom = Saisie.saisirUneChaine("Entrez le prénom : ");
        String telephone = Saisie.saisirUnTelephone("Entrez le téléphone :");
        repertoire.ajouter(new Personne(nom, prenom, telephone));
    }

    public void lister() {
        System.out.printf("%n%nGestion du répertoire : %s%n%n",
                repertoire.getNom());
        int i = 1;
        for (Personne personne : repertoire.getContacts()) {
            System.out.printf(
                    "%s - Nom : %-20s Prénom : %-20s Téléphone : %s%n", i++,
                    personne.getNom(), personne.getPrenom(),
                    personne.getTelephone());
        }
        System.out.println();
    }

    public void supprimer() {
        if (repertoire.getContacts().isEmpty()) return;

        Menu menuSupprimer = new Menu("Supression d'un contact", getOptionsFromRepertoire());
        int choix = menuSupprimer.choisirUneOption();
        if (choix != 0)
            repertoire.supprimer(choix - 1);
    }

    public void modifier() {
        if (repertoire.getContacts().isEmpty()) return;

        Menu menuSupprimer = new Menu("Modification d'un contact", getOptionsFromRepertoire());
        int choix = menuSupprimer.choisirUneOption();
        if (choix != 0) {
            Personne personne = repertoire.getContacts().get(choix - 1);
            String telephone = Saisie.saisirUnTelephone("Entrez le téléphone :");
            personne.setTelephone(telephone);
            repertoire.modifier();
        }
    }

    private ArrayList<String> getOptionsFromRepertoire() {
        ArrayList<String> options = new ArrayList<>();
        options.add("Abandonner");
        for (Personne personne : repertoire.getContacts())
            options.add(personne.toString());
        return options;
    }
}
