package fr.fs.vue;
import java.util.ArrayList;
import java.util.List;

import fr.fs.outils.Saisie;

public class Menu {
	String titre;
	List<String> options;
	public Menu(String titre, ArrayList<String> options) {
		this.titre = titre;
		this.options = options;
	}

	public int choisirUneOption() {
		System.out.printf("%n%n%s%n", titre);
		for (int i = 1; i < options.size(); i++) {
			System.out.printf("%n%2d - %s", i, options.get(i));
		}
		System.out.printf("%n%n%d - %s%n%n", 0, options.get(0));
		return Saisie.saisirUnEntier("Votre choix : ", 0, options.size()-1);
	}
}
