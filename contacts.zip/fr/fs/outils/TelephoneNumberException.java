package fr.fs.outils;


@SuppressWarnings("serial")
public class TelephoneNumberException extends RuntimeException {

	TelephoneNumberException(String string) {
		super(string);
	}
}
