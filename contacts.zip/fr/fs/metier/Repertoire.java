package fr.fs.metier;

import java.util.ArrayList;
import java.util.List;

import fr.fs.dao.PersonneDAO;


public class Repertoire {
    private String nom;
    private List<Personne> personnes;
    private PersonneDAO personneDAO;
    private boolean isModified;


    public Repertoire(String nom) {
        this.nom = nom;
        personneDAO = new PersonneDAO(nom);
        personnes = personneDAO.lire();
        isModified = false;
    }

    public String getNom() {
        return nom;
    }

    public List<Personne> getContacts() {
        return personnes;
    }

    public void ajouter(Personne personneAjoute) {
        if (personnes.indexOf(personneAjoute) == -1) {
            personnes.add(personneAjoute);
            isModified = true;
        }
    }

    public void enregistrer() {
        personneDAO.ecrire(personnes);
        isModified = false;
    }

    public void supprimer(int numero) {
        personnes.remove(numero);
        isModified = true;
    }

    public void modifier()
    {
        isModified=true;
    }

    public boolean isModified() {
        return isModified;
    }
}
