package fr.em.metier;

import fr.em.outils.Tableau;

public class Salarie extends Personne {

	
	private Agence agence;
	private String dateEmbauche;
	Tableau<Enfant> enfants  = new Tableau <Enfant>();
	
	public Salarie(String nom, String prenom, String dateEmbauche, Agence agence) {
		super(nom, prenom);
		this.dateEmbauche = dateEmbauche;
		this.agence = agence;
	}

	
	public Tableau<Enfant> getEnfants() {
		return enfants;
	}
	
	public void addEnfant(Enfant enfant) {
		enfants.add(enfant);
	}


	public String getDateEmbauche() {
		return dateEmbauche;
	}


	public Agence getAgence() {
		return agence;
	}

	public void setAgence(Agence agence) {
		this.agence = agence;
	}
	
}
