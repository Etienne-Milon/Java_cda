package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import fr.em.metier.Personne;

class PersonneTest {

	Personne person = new Personne ("azi","aze");
	
	@Test
	void test() {
		person.setNom("az");
		assertEquals("Az",person.getNom());
		person.setPrenom("walala");
		assertEquals("Walala",person.getPrenom());
	}

}
