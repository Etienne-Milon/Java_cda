package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import fr.em.metier.Agence;
import fr.em.metier.Enfant;
import fr.em.metier.Salarie;

class SalarieTest {
	
	Agence agency = new Agence ("kek",true);
	Salarie bonpapa = new Salarie ("aze","azer","2020-05-2",agency);
	Enfant pipouJr = new Enfant("Louise","Michel","2015-01-01");
	Agence agency2 = new Agence ("kok",true);
	
	@Test
	void test() {
		bonpapa.addEnfant(pipouJr);
		bonpapa.setAgence(agency2);
		assertEquals(pipouJr,bonpapa.getEnfants().get(0));
		assertEquals(1,bonpapa.getEnfants().size());
		assertEquals("KOK",bonpapa.getAgence().getNom());
	}

}
