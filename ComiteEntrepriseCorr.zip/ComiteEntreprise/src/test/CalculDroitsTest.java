package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import fr.em.metier.Agence;
import fr.em.metier.Enfant;
import fr.em.metier.Salarie;
import fr.em.outilse.CalculDroits;

class CalculDroitsTest {

	Agence agency = new Agence ("panam",true);
	Agence agency2 = new Agence ("afpaLand",false);
	Salarie salaryman = new Salarie ("nomtest","prenomtest","2000-01-01",agency);
	Salarie salaryman2 = new Salarie ("nomtest2","prenomtest","2022-01-01",agency2);
	Enfant enfanttest = new Enfant ("nomtestenf","penomtest","2010-01-01");
	Enfant enfanttest2 = new Enfant ("nomtestenf2","penomtest2","2017-01-01");
	Enfant enfanttest3 = new Enfant ("nomtestenf3","penomtest2","2004-01-01");
	
	
	
	@Test
	void testage() {
		assertEquals(12, CalculDroits.age(enfanttest));
		assertEquals(5, CalculDroits.age(enfanttest2));
		assertEquals("2022-07-01",CalculDroits.dateRefChequesVacs());
		assertEquals(true,CalculDroits.calculDroitChVac(salaryman));
		assertEquals(false,CalculDroits.calculDroitChVac(salaryman2));
		assertEquals(0,CalculDroits.calculDroitChNoel(salaryman));
		salaryman.addEnfant(enfanttest);
		assertEquals(30,CalculDroits.calculDroitChNoel(salaryman));
		salaryman.addEnfant(enfanttest2);
		assertEquals(50,CalculDroits.calculDroitChNoel(salaryman));
		salaryman.addEnfant(enfanttest3);
		assertEquals(100,CalculDroits.calculDroitChNoel(salaryman));
		assertEquals(false,CalculDroits.ticketRestaurant(salaryman));
		assertEquals(true,CalculDroits.ticketRestaurant(salaryman2));
	}

}
