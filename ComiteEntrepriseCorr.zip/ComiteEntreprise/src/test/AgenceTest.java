package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import fr.em.metier.Agence;

class AgenceTest {

	
	Agence agencetestO = new Agence("testnomAg",true);

	@Test
	void test() {
		
		agencetestO.setNom("meudon");
		assertEquals("MEUDON", agencetestO.getNom());
		agencetestO.setRestaurant(false);
		assertEquals(false, agencetestO.getRestaurant());
	}

}
