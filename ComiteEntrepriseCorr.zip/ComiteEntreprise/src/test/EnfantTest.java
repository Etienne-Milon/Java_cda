package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import fr.em.metier.Enfant;

class EnfantTest {

	Enfant pipouJr = new Enfant("Louise","Michel","2015-01-01");
	
	@Test
	void test() {
		assertEquals("2015-01-01",pipouJr.getDateDeNaissance()) ;
	}

}
